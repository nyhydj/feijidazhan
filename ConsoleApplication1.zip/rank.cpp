#include<stdio.h>
#include<stdlib.h>
int ranking()
{
	FILE* fp1 = fopen("rank.txt", "w");
	if (fp1 == NULL)
	{
		return 0;
	}
}
